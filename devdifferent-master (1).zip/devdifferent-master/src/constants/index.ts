export const SPECIES_OPTIONS = [
  {
    value: "human",
    label: "Human",
  },
  {
    value: "animal",
    label: "Animal",
  },
  {
    value: "alien",
    label: "Alien",
  },
];

export const STATUS_OPTIONS = [
  {
    value: "alive",
    label: "Alive",
  },
  {
    value: "dead",
    label: "Dead",
  },
];
